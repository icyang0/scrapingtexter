'use strict';

var fs = require('fs');
const request = require('axios');
//const {extractTicketsFromHTML} = require('./helpers');

module.exports.gettickets = (event, context, callback) => {
 /*  const response = {
    statusCode: 200,
    body: JSON.stringify({
      message: 'Go Serverless v1.0! Your function executed successfully!',
      input: event,
    }),
  }; */

 // callback(null, response);
 // callback(null, 'Hello Poop!');

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // callback(null, { message: 'Go Serverless v1.0! Your function executed successfully!', event });
  
  //request('https://www.thedonkeysanctuary.org.uk/vacancies')
  
  
/* 	request('http://global.smtowntravel.com/onEvent/step_1.asp?Master_Idx=363&Master_Lang=EN&Main_res_day=&Main_res_seq=')
    .then(({data}) => {
      const tickets = extractTicketsFromHTML(data);
      callback(null, {tickets});
    })
    .catch(callback); */
	
	
	//request('http://global.smtowntravel.com/onEvent/step_1.asp?Master_Idx=363&Master_Lang=EN&Main_res_day=&Main_res_seq=')
	
////-----------------------------------------------------------------------'


	request('http://global.smtowntravel.com/')
	.then(({data}) => {
		//callback(null, {data});
		
		var goop = data.toString();
		var number = goop.indexOf("M Cultour Package")
		
		//return console.log(goop.indexOf("M Cultour Package"));
		return console.log(goop.substring(number, number+30));
		/* 
		fs.writeFile("\output.txt", data, function(err) {
			if(err) {
				return console.log(err);
			}
			console.log("The file was saved!");
		});  */
	  
	  
    })
    .catch(callback);
////-----------------------------------------------------------------------'


/* 	axios.post('http://global.smtowntravel.com/member/login.asp?ref=/onEvent/index.asp', {
		Mail: 'remuusx3@gmail.com',
		pwd: '7GIDVi5KugurnsyMY1SL'
	})
	.then(function (response) {
		//console.log(response);
		
		fs.writeFile("\output.txt", data, function(err) {
			if(err) {
				return console.log(err);
			}
			console.log("The file was saved!");
		}); 
		
		
		
	})
	.catch(function (error) {
		console.log(error);
	}); */


	
	
};
